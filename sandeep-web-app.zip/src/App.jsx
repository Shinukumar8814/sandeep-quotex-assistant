import React, { useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

const App = () => {
  const [sequence, setSequence] = useState([]);
  const [prediction, setPrediction] = useState(null);

  const handleAdd = (color) => {
    const newSequence = [...sequence, color];
    setSequence(newSequence);
    setPrediction(predictNext(newSequence));
  };

  const predictNext = (seq) => {
    const last = seq.slice(-3).join('-');
    const patterns = {
      'red-red-red': 'green',
      'green-green-green': 'red',
      'red-green-red': 'red',
      'green-red-green': 'green'
    };
    return patterns[last] || (Math.random() > 0.5 ? 'red' : 'green');
  };

  const chartData = {
    labels: sequence.map((_, i) => i + 1),
    datasets: [{
      label: 'Candle Color',
      data: sequence.map(c => c === 'red' ? 1 : 2),
      backgroundColor: sequence.map(c => c),
    }],
  };

  const chartOptions = {
    scales: {
      y: {
        ticks: {
          callback: (val) => (val === 1 ? 'Red' : 'Green'),
          stepSize: 1,
        },
        min: 0,
        max: 3,
      },
    },
  };

  return (
    <div style={{ padding: 20, maxWidth: 600, margin: '0 auto' }}>
      <h1>Sandeep – Quotex Assistant</h1>
      <div style={{ marginBottom: 20 }}>
        <button onClick={() => handleAdd('red')} style={{ backgroundColor: 'red', color: 'white', marginRight: 10, padding: 10 }}>Red</button>
        <button onClick={() => handleAdd('green')} style={{ backgroundColor: 'green', color: 'white', padding: 10 }}>Green</button>
      </div>
      <div style={{ marginBottom: 20 }}>
        <h2>Prediction</h2>
        <p>Next candle is likely: <strong style={{ color: prediction }}>{prediction?.toUpperCase()}</strong></p>
      </div>
      <div>
        <h2>Sequence Chart</h2>
        <Bar data={chartData} options={chartOptions} />
      </div>
    </div>
  );
};

export default App;
